package ma.fstm.ilisi.models.entities;

import java.util.*;

/**
 * 
 */
public class CarteBancaire {

    /**
     * Default constructor
     */
    public CarteBancaire() {
    }

    /**
     * 
     */
    private int numCB;

}