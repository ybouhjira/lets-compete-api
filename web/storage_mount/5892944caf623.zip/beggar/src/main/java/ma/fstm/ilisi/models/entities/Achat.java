package ma.fstm.ilisi.models.entities;

import java.util.*;

/**
 * 
 */
public class Achat {

    /**
     * Default constructor
     */
    public Achat() {
    }

    /**
     * 
     */
    private Date dateAchat;

    /**
     * 
     */
    private Set<Paiement> paiements;

    /**
     * 
     */
    private Set<LigneAchat> lignes;


}