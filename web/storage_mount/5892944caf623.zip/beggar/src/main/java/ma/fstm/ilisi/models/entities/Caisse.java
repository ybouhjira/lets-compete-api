package ma.fstm.ilisi.models.entities;

/**
 * 
 */
public class Caisse {

    /**
     * Default constructor
     */
    public Caisse() {
    }

    /**
     * 
     */
    private int id;

    /**
     * 
     */
    private int numCaisse;

    /**
     * 
     */
    private Caissier chef;

}