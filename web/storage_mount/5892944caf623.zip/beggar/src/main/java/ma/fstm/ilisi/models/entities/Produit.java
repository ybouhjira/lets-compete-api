package ma.fstm.ilisi.models.entities;

/**
 * 
 */
public class Produit {

    /**
     * Default constructor
     */
    public Produit() {
    }

    /**
     * 
     */
    private int code;

    /**
     * 
     */
    private String label;

    /**
     * 
     */
    private float prix;

    /**
     * 
     */
    private int qte;

    /**
     * 
     */
    private Categorie categorie;


}