package ma.fstm.ilisi.models.entities;

import java.util.*;

/**
 * 
 */
public class Cheque {

    /**
     * Default constructor
     */
    public Cheque() {
    }

    /**
     * 
     */
    private int numCheque;

    /**
     * 
     */
    private String nomBanque;

}