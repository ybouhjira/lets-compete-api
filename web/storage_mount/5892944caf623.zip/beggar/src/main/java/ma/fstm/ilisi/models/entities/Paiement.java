package ma.fstm.ilisi.models.entities;

/**
 * 
 */
public class Paiement {

    /**
     * Default constructor
     */
    public Paiement() {
    }

    /**
     * 
     */
    private Achat achat;

}