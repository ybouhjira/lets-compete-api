package ma.fstm.ilisi.models.entities;

import java.util.*;

/**
 * 
 */
public class Compte {

    /**
     * Default constructor
     */
    public Compte() {
    }

    /**
     * 
     */
    private int id;

    /**
     * 
     */
    private String login;

    /**
     * 
     */
    private String mdp;


}