package ma.fstm.ilisi.models.entities;

/**
 * 
 */
public class PaiementCash extends Paiement {

    /**
     * Default constructor
     */
    public PaiementCash() {
    }

}