package ma.fstm.ilisi.models.entities;

/**
 * 
 */
public class LigneAchat {

    /**
     * Default constructor
     */
    public LigneAchat() {
    }

    /**
     * 
     */
    private int quantite;

    /**
     * 
     */
    private Achat achat;

    /**
     * 
     */
    private Produit produit;

}