package ma.fstm.ilisi.models.entities;

/**
 * 
 */
public class PaiementCheque extends Paiement {

    /**
     * Default constructor
     */
    public PaiementCheque() {
    }

    /**
     * 
     */
    private Cheque chef;

}