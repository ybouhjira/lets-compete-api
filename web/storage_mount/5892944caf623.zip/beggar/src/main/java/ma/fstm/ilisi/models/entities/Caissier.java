package ma.fstm.ilisi.models.entities;

/**
 * 
 */
public class Caissier {

    /**
     * Default constructor
     */
    public Caissier() {
    }

    /**
     * 
     */
    private int id;

    /**
     * 
     */
    private String nom;

    /**
     * 
     */
    private String prenom;

    /**
     * 
     */
    private Compte compte;



}