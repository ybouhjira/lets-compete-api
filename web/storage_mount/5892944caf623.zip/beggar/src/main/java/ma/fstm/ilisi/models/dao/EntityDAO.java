package ma.fstm.ilisi.models.dao;


import java.sql.SQLException;
import java.util.List;

public interface EntityDAO<Entity> {

    boolean create(Entity entity) throws SQLException;
    boolean update(Entity entity) throws SQLException;
    boolean delete(Entity entity) throws SQLException;
    List<Entity> findAll() throws SQLException;
}
