package ma.fstm.ilisi.models.entities;

import java.util.*;

/**
 * 
 */
public class Categorie {

    /**
     * Default constructor
     */
    public Categorie() {
    }

    /**
     * 
     */
    private int id;

    /**
     * 
     */
    private String nom;

    /**
     * 
     */
    private Set<Produit> produits;

}