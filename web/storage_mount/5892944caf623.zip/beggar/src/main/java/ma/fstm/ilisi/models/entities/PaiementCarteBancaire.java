package ma.fstm.ilisi.models.entities;

/**
 * 
 */
public class PaiementCarteBancaire extends Paiement {

    /**
     * Default constructor
     */
    public PaiementCarteBancaire() {
    }

    /**
     * 
     */
    private CarteBancaire carteBancaire;

}